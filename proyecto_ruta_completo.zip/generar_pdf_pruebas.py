"""
Genera el documento PDF con las pruebas realizadas, a partir de la
ejecución REAL del sistema (main.py --pruebas). Este script es un
apoyo para armar el entregable; no es parte del algoritmo del sistema
experto en sí.

Uso:
    python3 generar_pdf_pruebas.py
Genera: Pruebas_Sistema_Rutas.pdf
"""

import io
import subprocess
import sys
from datetime import datetime

from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib.enums import TA_CENTER
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Preformatted, PageBreak
from reportlab.lib.colors import HexColor


def capturar_salida_pruebas() -> str:
    resultado = subprocess.run(
        [sys.executable, "main.py", "--pruebas"],
        capture_output=True, text=True, check=True,
    )
    return resultado.stdout


def construir_pdf(salida_texto: str, ruta_salida: str) -> None:
    doc = SimpleDocTemplate(
        ruta_salida, pagesize=letter,
        topMargin=2 * cm, bottomMargin=2 * cm, leftMargin=2 * cm, rightMargin=2 * cm,
    )
    estilos = getSampleStyleSheet()

    titulo = ParagraphStyle(
        "TituloCustom", parent=estilos["Title"], alignment=TA_CENTER, fontSize=18,
    )
    subtitulo = ParagraphStyle(
        "SubtituloCustom", parent=estilos["Normal"], alignment=TA_CENTER,
        fontSize=11, textColor=HexColor("#555555"),
    )
    seccion = ParagraphStyle(
        "SeccionCustom", parent=estilos["Heading2"], spaceBefore=14, spaceAfter=6,
    )
    codigo = ParagraphStyle(
        "CodigoCustom", parent=estilos["Code"], fontSize=8, leading=10,
        backColor=HexColor("#f4f4f4"),
    )

    story = []
    story.append(Paragraph("Sistema Experto de Rutas para Transporte Masivo", titulo))
    story.append(Spacer(1, 6))
    story.append(Paragraph(
        "Sistema basado en reglas lógicas y búsqueda heurística (A*)<br/>"
        f"Documento de pruebas generado automáticamente &middot; {datetime.now().strftime('%d/%m/%Y %H:%M')}",
        subtitulo,
    ))
    story.append(Spacer(1, 18))

    story.append(Paragraph("1. Objetivo de las pruebas", seccion))
    story.append(Paragraph(
        "Verificar que el sistema experto, a partir de la base de conocimiento en reglas "
        "lógicas (base_conocimiento.py) y el motor de búsqueda heurística A* "
        "(motor_busqueda.py), calcula correctamente la mejor ruta (menor tiempo total, "
        "incluyendo penalización por transbordos) entre dos estaciones de una red de "
        "transporte masivo simulada, y maneja adecuadamente los casos de error "
        "(estación inexistente, origen igual a destino).",
        estilos["Normal"],
    ))
    story.append(Spacer(1, 10))

    story.append(Paragraph("2. Casos de prueba ejecutados", seccion))
    casos_md = [
        ("Caso 1", "Portal_Norte &rarr; Portal_Sur", "Ruta directa, una sola línea, sin transbordos."),
        ("Caso 2", "Portal_Suba &rarr; Portal_Sur", "Ruta que requiere 1 transbordo entre dos líneas."),
        ("Caso 3", "Portal_80 &rarr; Heroes", "Ruta que requiere 2 transbordos (caso más complejo)."),
        ("Caso 4", "Calle_100 &rarr; Calle_100", "Caso borde: origen = destino (debe rechazarse)."),
        ("Caso 5", "Portal_Norte &rarr; Marte", "Caso borde: estación destino inexistente (debe rechazarse)."),
    ]
    for nombre, ruta, desc in casos_md:
        story.append(Paragraph(f"<b>{nombre}</b> ({ruta}): {desc}", estilos["Normal"]))
    story.append(Spacer(1, 10))

    story.append(Paragraph("3. Resultado de la ejecución (salida real de la consola)", seccion))
    story.append(Paragraph(
        "A continuación se muestra la salida completa y sin editar de ejecutar "
        "<font face='Courier'>python3 main.py --pruebas</font> sobre el código fuente entregado:",
        estilos["Normal"],
    ))
    story.append(Spacer(1, 8))

    ancho_max = 92
    lineas_ajustadas = []
    for linea in salida_texto.split("\n"):
        while len(linea) > ancho_max:
            lineas_ajustadas.append(linea[:ancho_max])
            linea = linea[ancho_max:]
        lineas_ajustadas.append(linea)
    texto_formateado = "\n".join(lineas_ajustadas)

    story.append(Preformatted(texto_formateado, codigo))
    story.append(Spacer(1, 10))

    story.append(Paragraph("4. Conclusión de las pruebas", seccion))
    story.append(Paragraph(
        "Los 5 casos de prueba se ejecutaron exitosamente: el sistema calculó rutas óptimas "
        "correctas en los casos 1, 2 y 3 (incluyendo el conteo correcto de transbordos y el "
        "tiempo total en minutos), y respondió de forma controlada, sin errores ni caídas del "
        "programa, ante los casos borde 4 y 5. Esto confirma que la base de conocimiento, el "
        "grafo derivado y el motor de búsqueda A* funcionan de manera integrada y consistente.",
        estilos["Normal"],
    ))

    doc.build(story)


if __name__ == "__main__":
    salida = capturar_salida_pruebas()
    construir_pdf(salida, "Pruebas_Sistema_Rutas.pdf")
    print("PDF generado: Pruebas_Sistema_Rutas.pdf")
